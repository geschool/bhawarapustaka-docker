###Loan Report

Contains information about borrowing. Consists of: 
- Total lending, 
- Lending based on GMD, 
- Lending by the collection type, 
- Total lending transactions, 
- The average transaction per day, 
- Member who have loans, 
- Members who do not have loans, and 
- Total overdues loans.
