###Lista de miembros

Este informe contiene una lista de miembros de la biblioteca. En este menú hay una opción para ordenar e imprimir. Además, también hay servicios de filtro, basados en:
- Tipo de membresía,
- ID del miembro / Nombre del miembro,
- Género,
- Dirección,
- "Fecha de registro desde,"
- "Fecha de registro hasta."

Esta característica también proporciona la facilidad de crear una descarga de un archivo de hoja de cálculo. Los archivos se pueden obtener haciendo clic en "Exportar a formato de hoja de cálculo".