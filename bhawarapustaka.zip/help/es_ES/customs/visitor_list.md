###Lista de visitantes

Este informe contiene una lista de nombres de miembros de la biblioteca o no que visitan la misma. Este informe contiene información sobre:
- Identificación del miembro,
- Nombre del visitante,
- Tipo de membresía,
- Institución, y
- Fecha de la visita.