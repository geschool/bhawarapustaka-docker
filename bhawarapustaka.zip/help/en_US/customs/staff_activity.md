### Aktivitas staff
<hr>
Menu ini memperlihatkan aktifitas Staff perpustakaan yang mempunyai account di aplikasi Senayan. Informasi yang ditampilkan adalah Username, Login Name, Bibliografy data entry, Item data Entry, Member data entry, dan Circulation. Jadi dengan menu ini akan terlihat staff melakukan apa dan berapa kali.

Untuk memperakurat informasi, disediakan pula filter yang memungkinkan kita melihat aktifitas dari tanggal awal sampai akhir (seperti yang ditentukan).