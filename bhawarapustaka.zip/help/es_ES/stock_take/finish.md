###Finalizar inventario
<hr>
Haga clic en este enlace si ha terminado el inventario. En el menú, hay un campo etiquetado como Purgar ejemplares perdidos, si ponemos una marca de verificación en Sí, todos los ejemplares de la colección que se encuentren en Ejemplares perdidos se les modificará su estado a "Perdido".