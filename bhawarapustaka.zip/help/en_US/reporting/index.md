###Collection Statistic

Contains the total collection information for:
- Titles, 
- Total items, 
- Total items being borrowed, 
- Total items that were in the library (not borrowed), 
- Total titles based GMD, 
- Total collection of items by type, and 
- Ten (10) most popular collection of titles (most borrowed).
