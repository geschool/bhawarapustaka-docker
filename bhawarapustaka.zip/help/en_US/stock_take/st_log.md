## StockTake Log
<hr>
The function of this menu is to find log records when doing the stock-take