###Actividad del personal

Este menú muestra las actividades del personal de la biblioteca que tienen una cuenta en la aplicación. La información mostrada es:
- Nombre de usuario,
- Nombre de inicio de sesión,
- Entrada de datos bibliográficos,
- Entrada de datos de ejemplares,
- Entrada de datos de miembros, y
- Circulación.

Así que este menú hará visible qué personal hizo qué y cuántas veces.