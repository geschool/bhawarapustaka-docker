####Archivo maestro / Estado del ejemplar
<hr>
Contiene el estado del ejemplar (Reparación, En préstamo, Reservado, etc.). Cada categoría de estado del ejemplar contiene el código de estado, el nombre del estado y las reglas. Hay dos opciones en las reglas:
- Sin transacción de préstamo (los ejemplares no pueden ser prestados, por ejemplo: las colecciones digitales) y
- No previsto por el inventario (no se incluirá en el proceso de inventario)