###Visitor List

This report contains a list of names of library members or non-members who visit the library. This report contains information: 
- Member ID, 
- Visitor Name, 
- Membership Type, 
- Institution, and 
- Visit Date.
